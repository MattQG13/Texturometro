#include "MAX7221.h"

//-----------------------------------------------------------------------------------//
MAX7221::MAX7221(int SlavePin)
{
    slaveSelectPin = SlavePin;
    pinMode(slaveSelectPin, OUTPUT);
    digitalWrite(slaveSelectPin, HIGH);
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Open()
{
    Write(0x0C,0x01);     
    Write(0x0B,0x07);
    Write(0x0A,0x07);
    Write(0x09,0xFF);  
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Close()
{
  
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Blink()
{
    char a_trace[6] = {0x0A,0x0A,0x0A,0x0A,0x0A,0x0A};
    char a_blank[6] = {0x0F,0x0F,0x0F,0x0F,0x0F,0x0F};
    for(int i=0; i<= 10; i++)
    {
        Display(a_trace, 6);
        delay(50);
        Display(a_blank, 6);
        delay(50);
    }
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Value(int value)
{
    char tmp;
    char a_vetor[6];
    int lenght = 0;
    int i;
    
    //conversão para string 
    sprintf(a_vetor, "%d", value);

    //verifico o tamanho do numero
    do
    {
        lenght = lenght + 1;
        value = value / 10;
    }
    while (value != 0);    
    
    //Faz a correção da ordem do vetor para o MAX7221
    for (i = 0; i < ( lenght / 2 ); i++ )
    {
        tmp = a_vetor[i];
        a_vetor[i] = a_vetor[ (lenght - 1) - i ];
        a_vetor[ (lenght - 1) - i ] = tmp;
    }
  
    //Apaga os caractares não usados
    for (i = 0; i <= (6 - lenght); i++ )
    {
        a_vetor[6 - i] = 0x0F;
    }
    
    //Zera variável tamanho
    lenght = 0;

    //Envio os dados para o display
    Display(a_vetor, 6);   
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Display(char *data, char lenght)
{
    Write(0x08,0x0F);      
    Write(0x07,0x0F); 
    Write(0x06,data[5]);
    Write(0x05,data[4]);     
    Write(0x04,data[3]);     
    Write(0x03,data[2]);     
    Write(0x02,data[1]);     
    Write(0x01,data[0]); 
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void MAX7221::Write(int address, int value)
{
    digitalWrite(slaveSelectPin, LOW);
    SPI.transfer(address);
    SPI.transfer(value);
    digitalWrite(slaveSelectPin, HIGH);  
}
//-----------------------------------------------------------------------------------//
