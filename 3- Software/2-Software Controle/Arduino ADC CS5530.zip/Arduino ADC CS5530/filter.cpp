#include "filter.h"

//-----------------------------------------------------------------------------------//
Filter::Filter()
{

}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void Filter::Open()
{

}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
void Filter::Close()
{
  
}
//-----------------------------------------------------------------------------------//

//-----------------------------------------------------------------------------------//
uint16_t Filter::moving_avg(uint16_t data)
{
    uint8_t i = 0;
    uint32_t soma = 0;
    uint32_t media = 0;

    //Copio o buffer para o buffer auxiliar 
    for( i = 0; i < ORDER; i++ )
    {
        BufferAux_AN0[i] = BufferFiltro_AN0[i];
    }

    //Incrementado em uma posição o buffer do filtro e insiro a nova medição
    for( i = 0; i < ORDER; i++)
    {
        if(i < (ORDER-1))
        {
            BufferFiltro_AN0[i+1] = BufferAux_AN0[i];
        }
        else
        {
            BufferFiltro_AN0[0] = data;
        }
    }

    //Realizo a soma de todos os elementos do buffer do filtro
    for( i = 0; i < ORDER; i++)
    {
        soma = soma + BufferFiltro_AN0[i]; 
    }

    //Calculo a média da soma
    media = soma / ORDER;

    return (uint16_t) media;
}
//-----------------------------------------------------------------------------------//

