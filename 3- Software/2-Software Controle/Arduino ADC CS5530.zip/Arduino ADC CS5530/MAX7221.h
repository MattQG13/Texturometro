#ifndef MAX7221_H
#define MAX7221_H

#include <stdio.h>
#include <string.h>
#include <Arduino.h>
#include <SPI.h>

class MAX7221
{
public:
    MAX7221(int SlavePin);
    void Open();
    void Close();
    void Blink();
    void Value(int value);
private:
    int slaveSelectPin;
    void Display(char *data, char lenght);
    void Write(int address, int value);
};

#endif
