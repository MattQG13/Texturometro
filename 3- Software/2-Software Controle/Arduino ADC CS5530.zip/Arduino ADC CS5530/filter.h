#ifndef FILTER_H
#define FILTER_H

#include <stdio.h>
#include <string.h>
#include <Arduino.h>

#define ORDER  32


class Filter
{
public:
    Filter();
    void Open();
    void Close();
    uint16_t moving_avg(uint16_t data);
private:
    uint16_t BufferFiltro_AN0[ORDER];
    uint16_t BufferAux_AN0[ORDER];
};

#endif
